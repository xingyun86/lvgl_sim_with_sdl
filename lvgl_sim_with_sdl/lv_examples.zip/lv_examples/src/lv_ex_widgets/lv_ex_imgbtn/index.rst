C
^

Simple Image button 
"""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_imgbtn/lv_ex_imgbtn_1.*
  :alt: Image button example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_imgbtn/lv_ex_imgbtn_1.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
