C
^

Several object masks
""""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_objmask/lv_ex_objmask_1.*
  :alt: Page example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_objmask/lv_ex_objmask_1.c
      :language: c
      
      
Text mask
"""""""""""""""""""

.. image:: /lv_examples/src/lv_ex_widgets/lv_ex_objmask/lv_ex_objmask_2.*
  :alt: Page example in LittlevGL

.. container:: toggle

    .. container:: header
    
      code

    .. literalinclude:: /lv_examples/src/lv_ex_widgets/lv_ex_objmask/lv_ex_objmask_2.c
      :language: c

MicroPython
^^^^^^^^^^^

No examples yet.
